package com.project.OFH.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.OFH.entity.Review;
import com.project.OFH.repository.ReviewRepository;
@SpringBootTest
class ReviewServiceImplTest {

	@Mock
	ReviewRepository reviewRepository;;
	
	@InjectMocks
	ReviewServiceImpl reviewService;
	
     @Test

     @DisplayName(" create review")
	void testcreateReview()throws Exception{
	   
	//given
    	 Review sampleInput = new Review("good product","product is well to use",5,LocalDate.of(2022, 11, 14),"Ram","camera");
 		Review expectedOutput = new Review("good product","product is well to use",5,LocalDate.of(2022, 11, 14),"Ram","camera");
		BDDMockito.given(reviewService.createReview(sampleInput)).willReturn(expectedOutput);
		
		// when 
		Review actualOutput = reviewService.createReview(sampleInput);
     
		//verify
		assertEquals(expectedOutput,actualOutput);
	
     }
			
	@Test
	
    @DisplayName(" Get reviews")
     void testGetReviews()throws Exception {
		Review review1 = new Review("good product","product is well to use",5,LocalDate.of(2022, 11, 14),"Ram","camera");
		Review review2 = new Review("Bad product","product is not well to use",2,LocalDate.of(2022, 11, 14),"Ramesh","Laptop");
		Review review3 = new Review("average product","price is too high",3,LocalDate.of(2022, 11, 13),"sita","dress");
		List<Review> sampleOutput = new ArrayList<>();
		sampleOutput.add(review1);
		sampleOutput.add(review2);
		BDDMockito.given(reviewService.getReviews()).willReturn(sampleOutput);
		
		//when
		List<Review> actualOutput = reviewService.getReviews();
		//Verify
		assertEquals(sampleOutput,actualOutput);
		assertSame(sampleOutput.add(review1),actualOutput.add(review2));

		}

	@Test
	
	
		 @DisplayName(" Get reviews")
		 void testUpdateReviews()throws Exception {
			Review review4 = new Review("good product","product is well to use",4,LocalDate.of(2022, 11, 14),"Ram","camera");
			Review review5 = new Review("Bad product","product is not well to use",1,LocalDate.of(2022, 11, 15),"Ramesh","Laptop");
			List<Review> sampleOutput = new ArrayList<>();
			sampleOutput.add(review4);
			sampleOutput.add(review5);
			BDDMockito.given(reviewService.getReviews()).willReturn(sampleOutput);
		 
			
			//when
			List<Review> actualOutput = reviewService.getReviews();
			//Verify
			assertEquals(sampleOutput,actualOutput);
			assertSame(sampleOutput.add(review4),actualOutput.add(review5));

	}
	

	@Test

	@DisplayName("delete review")
	void testDeleteReview() throws Exception {
		Review review2 = new Review("good product","product is well to use",4,LocalDate.of(2022, 11, 15),"Ram","camera");
		
		List<Review> sampleOutput = new ArrayList<>();
		sampleOutput.add(review2);
		
		BDDMockito.given(reviewService.getReviews()).willReturn(sampleOutput);
	 
		
		//when
		List<Review> actualOutput = reviewService.getReviews();
		//Verify
		assertEquals(sampleOutput,actualOutput);
		

		
	}

	@Test
	
	@DisplayName("filter review by username")
	void testFilterReview() throws Exception{
		
			Review review1 = new Review("good product","product is well to use",5,LocalDate.of(2022, 11, 14),"Ram","camera");
			
			List<Review> sampleOutput = new ArrayList<>();
			sampleOutput.add(review1);
			
			BDDMockito.given(reviewService.getReviews()).willReturn(sampleOutput);
			
			//when
			List<Review> actualOutput = reviewService.getReviews();
			//Verify
			assertEquals(sampleOutput,actualOutput);
			

		
	}

	@Test
	
	@DisplayName("filter by date")
	void testFilterByDate() throws Exception {
		
			Review review1 = new Review("good product","product is well to use",5,LocalDate.of(2022, 11, 13),"Ram","camera");
			
			List<Review> sampleOutput = new ArrayList<>();
			sampleOutput.add(review1);
			
			BDDMockito.given(reviewService.getReviews()).willReturn(sampleOutput);
			
			//when
			List<Review> actualOutput = reviewService.getReviews();
			//Verify
			assertEquals(sampleOutput,actualOutput);
			

	}

	@Test
	
	void testSortReview() throws Exception {
		
			Review review1 = new Review("good product","product is well to use",5,LocalDate.of(2022, 11, 13),"Ram","camera");
			
			Review review3 = new Review("average product","price is too high",3,LocalDate.of(2022, 11, 15),"sita","dress");
			List<Review> sampleOutput = new ArrayList<>();
			sampleOutput.add(review1);
			sampleOutput.add(review3);
			BDDMockito.given(reviewService.getReviews()).willReturn(sampleOutput);
			
			//when
			List<Review> actualOutput = reviewService.getReviews();
			//Verify
			assertEquals(sampleOutput,actualOutput);
			assertSame(sampleOutput.add(review1),actualOutput.add(review3));

		
	}

}