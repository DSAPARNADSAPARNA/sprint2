package com.project.OFH.exceptions;

	@SuppressWarnings("serial")
	public class ReviewNotFoundException extends RuntimeException{
		public ReviewNotFoundException(String msg)
		{
			super(msg);
		}
	}



