package com.project.OFH.exceptions;

	
	public class DateNotFoundException extends RuntimeException{
		public DateNotFoundException(String msg)
		{
			super(msg);
		}
	} 



