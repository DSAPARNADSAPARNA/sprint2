package com.project.OFH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineFashionHouseProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineFashionHouseProjectApplication.class, args);
	}

}
